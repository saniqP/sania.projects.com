#include "pyPack.hpp"
#include <iostream>
using namespace std;

void print(string text, bool end = true) {
	if (end) {
		cout << text << endl;
	}
	else {
		cout << text;
	}
}