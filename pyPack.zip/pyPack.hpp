#ifdef PRINT_HPP
#define PRINT_HPP
#include <iostream>
using namespace std;

void print(string text, bool end = true);

template<typename T>
T input(string message, bool end = false);

#endif