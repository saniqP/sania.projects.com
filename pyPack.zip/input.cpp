#include "pyPack.hpp"
#include <iostream>
using namespace std;

template<typename T>
T input(string message, bool end = false) {
	T returnValue;
	if (!end) {
		cout << message;
		cin >> returnValue;
	}
	else {
		cout << message << endl;
		cin >> returnValue;
	}
	return returnValue;
}